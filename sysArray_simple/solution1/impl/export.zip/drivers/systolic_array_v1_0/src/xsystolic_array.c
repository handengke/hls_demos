// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xsystolic_array.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSystolic_array_CfgInitialize(XSystolic_array *InstancePtr, XSystolic_array_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSystolic_array_Set_din_a(XSystolic_array *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_array_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_A_DATA, (u32)(Data));
    XSystolic_array_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_A_DATA + 4, (u32)(Data >> 32));
}

u64 XSystolic_array_Get_din_a(XSystolic_array *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_array_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_A_DATA);
    Data += (u64)XSystolic_array_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_A_DATA + 4) << 32;
    return Data;
}

void XSystolic_array_Set_din_b(XSystolic_array *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_array_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_B_DATA, (u32)(Data));
    XSystolic_array_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_B_DATA + 4, (u32)(Data >> 32));
}

u64 XSystolic_array_Get_din_b(XSystolic_array *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_array_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_B_DATA);
    Data += (u64)XSystolic_array_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_B_DATA + 4) << 32;
    return Data;
}

void XSystolic_array_Set_out_r(XSystolic_array *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSystolic_array_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_OUT_R_DATA, (u32)(Data));
    XSystolic_array_WriteReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_OUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XSystolic_array_Get_out_r(XSystolic_array *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSystolic_array_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_OUT_R_DATA);
    Data += (u64)XSystolic_array_ReadReg(InstancePtr->Control_BaseAddress, XSYSTOLIC_ARRAY_CONTROL_ADDR_OUT_R_DATA + 4) << 32;
    return Data;
}

