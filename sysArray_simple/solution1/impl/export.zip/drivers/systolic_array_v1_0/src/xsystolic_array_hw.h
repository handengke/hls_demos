// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of din_a
//        bit 31~0 - din_a[31:0] (Read/Write)
// 0x14 : Data signal of din_a
//        bit 31~0 - din_a[63:32] (Read/Write)
// 0x18 : reserved
// 0x1c : Data signal of din_b
//        bit 31~0 - din_b[31:0] (Read/Write)
// 0x20 : Data signal of din_b
//        bit 31~0 - din_b[63:32] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of out_r
//        bit 31~0 - out_r[31:0] (Read/Write)
// 0x2c : Data signal of out_r
//        bit 31~0 - out_r[63:32] (Read/Write)
// 0x30 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_A_DATA 0x10
#define XSYSTOLIC_ARRAY_CONTROL_BITS_DIN_A_DATA 64
#define XSYSTOLIC_ARRAY_CONTROL_ADDR_DIN_B_DATA 0x1c
#define XSYSTOLIC_ARRAY_CONTROL_BITS_DIN_B_DATA 64
#define XSYSTOLIC_ARRAY_CONTROL_ADDR_OUT_R_DATA 0x28
#define XSYSTOLIC_ARRAY_CONTROL_BITS_OUT_R_DATA 64

